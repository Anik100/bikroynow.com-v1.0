'use client';

import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import Link from 'next/link';
import { supabase } from '../lib/supabaseClient';
import styles from './page.module.css';
import { CATEGORIES } from '../lib/constants';
import { useLanguage } from '../context/LanguageContext';
import { getRelativeTime, formatFullDate, formatPrice, getPromotionBadgeText } from '../lib/utils';
import { Heart, Smartphone, Laptop, Zap, Car, Home as HouseIcon, Briefcase, Box, ChevronDown } from 'lucide-react';
import FeaturedSlider from '../components/FeaturedSlider';

const getSellerBadge = (profiles, lang) => {
  if (!profiles) return null;
  const expiresAt = profiles.membership_expires_at ? new Date(profiles.membership_expires_at) : null;
  const isNotExpired = !expiresAt || new Date() < expiresAt;

  if (profiles.membership_type && profiles.membership_type !== 'free' && isNotExpired) {
    const name = profiles.membership_type.toLowerCase();
    let badgeStyle = {
      background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
      color: 'white',
      border: '1px solid #34d399'
    };
    let label = profiles.membership_type;

    if (name.includes('silver')) {
      badgeStyle = {
        background: 'linear-gradient(135deg, #f1f5f9 0%, #cbd5e1 100%)',
        color: '#334155',
        border: '1px solid #cbd5e1'
      };
      label = lang === 'bn' ? 'সিলভার মেম্বার' : 'Silver Member';
    } else if (name.includes('gold')) {
      badgeStyle = {
        background: 'linear-gradient(135deg, #fef08a 0%, #ca8a04 100%)',
        color: '#713f12',
        border: '1px solid #fde047'
      };
      label = lang === 'bn' ? 'গোল্ড মেম্বার' : 'Gold Member';
    } else if (name.includes('business')) {
      badgeStyle = {
        background: 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)',
        color: 'white',
        border: '1px solid #60a5fa'
      };
      label = lang === 'bn' ? 'বিজনেস মেম্বার' : 'Business Member';
    } else {
      if (lang === 'bn') {
        const translations = {
          '3-day express boost': '৩ দিনের এক্সপ্রেস বুস্ট',
          '7-day premium boost': '৭ দিনের প্রিমিয়াম বুস্ট',
          '15-day mega boost': '১৫ দিনের মেগা বুস্ট'
        };
        label = translations[name] || label;
      }
    }

    const shieldSvg = (
      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: '3px', flexShrink: 0 }}>
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
      </svg>
    );

    return (
      <span style={{
        display: 'inline-flex',
        alignItems: 'center',
        fontSize: '0.62rem',
        fontWeight: 800,
        padding: '0.15rem 0.4rem',
        borderRadius: '5px',
        textTransform: 'uppercase',
        letterSpacing: '0.3px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
        gap: '0.15rem',
        lineHeight: 1,
        ...badgeStyle
      }}>
        {shieldSvg}
        {label}
      </span>
    );
  }
  return null;
};

export default function Home() {
  const { t, lang } = useLanguage();
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [activeCategory, setActiveCategory] = useState(null);
  const [activeSub, setActiveSub] = useState(null);
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isCategoriesExpanded, setIsCategoriesExpanded] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Favorites state
  const [favorites, setFavorites] = useState([]);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchListings = async () => {
      try {
        setLoading(true);
        let { data, error } = await supabase
          .from('listings')
          .select('*')
          .neq('status', 'pending')
          .order('created_at', { ascending: false })
          .limit(10);
        
        if (error) {
          console.error('Error fetching listings:', error);
          setListings([]);
        } else if (data && data.length > 0) {
          // Fetch user profiles to display their membership badges
          const userIds = [...new Set(data.map(item => item.user_id).filter(Boolean))];
          if (userIds.length > 0) {
            const { data: profilesData } = await supabase
              .from('profiles')
              .select('id, membership_type, membership_expires_at')
              .in('id', userIds);
              
            if (profilesData) {
              const profilesMap = {};
              profilesData.forEach(p => {
                profilesMap[p.id] = p;
              });
              const enrichedData = data.map(item => ({
                ...item,
                profiles: profilesMap[item.user_id] || null
              }));
              setListings(enrichedData);
            } else {
              setListings(data);
            }
          } else {
            setListings(data);
          }
        } else {
          setListings(data || []);
        }
      } catch (err) {
        console.error('Unexpected error fetching listings:', err);
        setListings([]);
      } finally {
        setLoading(false);
      }
    };
    fetchListings();
  }, []);

  // Fetch session and user's favorites dynamically
  useEffect(() => {
    const fetchFavorites = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        setUser(session.user);
        const { data } = await supabase
          .from('favorites')
          .select('listing_id')
          .eq('user_id', session.user.id);
        if (data) {
          setFavorites(data.map(f => f.listing_id));
        }
      }
    };

    fetchFavorites();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (session?.user) {
        setUser(session.user);
        const { data } = await supabase
          .from('favorites')
          .select('listing_id')
          .eq('user_id', session.user.id);
        if (data) {
          setFavorites(data.map(f => f.listing_id));
        }
      } else {
        setUser(null);
        setFavorites([]);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const toggleFavorite = async (e, adId) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      alert(lang === 'bn' ? 'প্রিয় বিজ্ঞাপনের তালিকা ব্যবহার করতে অনুগ্রহ করে লগইন করুন।' : 'Please login to use favorites.');
      return;
    }

    const isFav = favorites.includes(adId);

    // Optimistic UI Update: turn it red/empty instantly
    if (isFav) {
      setFavorites(prev => prev.filter(id => id !== adId));
    } else {
      setFavorites(prev => [...prev, adId]);
    }

    if (isFav) {
      // Remove favorite
      const { error } = await supabase
        .from('favorites')
        .delete()
        .eq('user_id', user.id)
        .eq('listing_id', adId);
      if (error) {
        // Revert on error
        setFavorites(prev => [...prev, adId]);
        console.error('Error removing favorite:', error);
      }
    } else {
      // Add favorite
      const { error } = await supabase
        .from('favorites')
        .insert({ user_id: user.id, listing_id: adId });
      if (error) {
        // Revert on error
        setFavorites(prev => prev.filter(id => id !== adId));
        console.error('Error adding favorite:', error);
      }
    }
  };

  // Handle native mobile/browser back button to close the modal
  useEffect(() => {
    if (showCategoryModal) {
      window.history.pushState({ modalOpen: true }, '');
      
      const handlePopState = (e) => {
        setShowCategoryModal(false);
      };

      window.addEventListener('popstate', handlePopState);
      return () => {
        window.removeEventListener('popstate', handlePopState);
      };
    }
  }, [showCategoryModal]);

  const closeCategoryModal = () => {
    setShowCategoryModal(false);
    setActiveCategory(null);
    setActiveSub(null);
    if (window.history.state && window.history.state.modalOpen) {
      window.history.back();
    }
  };

  const categories = [
    { 
      name: 'Mobile Phones', 
      icon: Smartphone, 
      color: '#2563eb', 
      bg: '#f0f7ff', 
      border: '#bfdbfe', 
      text: '#1e40af', 
      gradient: 'linear-gradient(135deg, #1d4ed8 0%, #3b82f6 50%, #60a5fa 100%)' 
    },
    { 
      name: 'Computers', 
      icon: Laptop, 
      color: '#059669', 
      bg: '#ecfdf5', 
      border: '#a7f3d0', 
      text: '#065f46', 
      gradient: 'linear-gradient(135deg, #047857 0%, #10b981 50%, #34d399 100%)' 
    },
    { 
      name: 'Electronics', 
      icon: Zap, 
      color: '#d97706', 
      bg: '#fffbeb', 
      border: '#fde68a', 
      text: '#92400e', 
      gradient: 'linear-gradient(135deg, #b45309 0%, #f59e0b 50%, #fbbf24 100%)' 
    },
    { 
      name: 'Vehicles', 
      icon: Car, 
      color: '#dc2626', 
      bg: '#fef2f2', 
      border: '#fca5a5', 
      text: '#991b1b', 
      gradient: 'linear-gradient(135deg, #b91c1c 0%, #ef4444 50%, #f87171 100%)' 
    },
    { 
      name: 'Property', 
      icon: HouseIcon, 
      color: '#7c3aed', 
      bg: '#f5f3ff', 
      border: '#ddd6fe', 
      text: '#5b21b6', 
      gradient: 'linear-gradient(135deg, #6d28d9 0%, #8b5cf6 50%, #a78bfa 100%)' 
    },
    { 
      name: 'Jobs', 
      icon: Briefcase, 
      color: '#db2777', 
      bg: '#fdf2f8', 
      border: '#fbcfe8', 
      text: '#9d174d', 
      gradient: 'linear-gradient(135deg, #be185d 0%, #ec4899 50%, #f472b6 100%)' 
    },
    { 
      name: 'অন্যান্য', 
      icon: Box, 
      color: '#475569', 
      bg: '#f8fafc', 
      border: '#cbd5e1', 
      text: '#1e293b', 
      gradient: 'linear-gradient(135deg, #334155 0%, #64748b 50%, #94a3b8 100%)' 
    },
  ];

  return (
    <div className={styles.homeContainer}>
      <div className={`container ${styles.categorySection}`}>
        <div 
          className={styles.sectionTitleToggle} 
          onClick={() => setIsCategoriesExpanded(!isCategoriesExpanded)}
        >
          <div className={styles.titleLeft}>
            <span className={styles.accentBar}></span>
            <h2 className={styles.sectionTitleText}>
              {t('browseCategories')}
            </h2>
          </div>
          <div className={styles.chevronCircle}>
            <svg 
              className={`${styles.chevronIcon} ${isCategoriesExpanded ? styles.rotated : ''}`} 
              width="18" 
              height="18" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="3.5" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>
        </div>

        <div className={`${styles.sliderWrapper} ${isCategoriesExpanded ? styles.expanded : ''}`}>
          <div className={styles.sliderContent}>
            <div className={styles.categoryGrid}>
              {categories.map((cat, i) => (
                <div 
                  key={i} 
                  className={styles.categoryCard}
                  style={{
                    '--card-bg': cat.bg,
                    '--card-border': cat.border,
                    '--card-text': cat.text,
                    '--icon-glow': cat.color
                  }}
                  onClick={() => {
                    setActiveCategory(cat.name);
                    if (CATEGORIES[cat.name]) {
                      const firstSub = Object.keys(CATEGORIES[cat.name])[0];
                      setActiveSub(firstSub);
                    } else {
                      setActiveSub(null);
                    }
                    setShowCategoryModal(true);
                  }}
                >
                  <div className={styles.iconBox} style={{ background: cat.gradient }}>
                    <cat.icon size={20} color="#ffffff" className={styles.categoryIcon} />
                  </div>
                  <h3 style={{ color: cat.text }}>{t(cat.name)}</h3>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {showCategoryModal && activeCategory && mounted && createPortal(
        <div className={styles.modalOverlay} onClick={closeCategoryModal}>
          <div className={styles.modalContent} onClick={e => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <h2 className={styles.modalTitle}>{t(activeCategory)}</h2>
              <button className={styles.modalCloseBtn} onClick={closeCategoryModal}>
                {lang === 'bn' ? '← ফিরে যান' : '← Go Back'}
              </button>
            </div>
            <div className={styles.modalBody}>
              {CATEGORIES[activeCategory] ? (
                Object.keys(CATEGORIES[activeCategory]).map(sub => {
                  const isExpanded = activeSub === sub;
                  return (
                    <div key={sub} className={styles.subCatAccordionGroup}>
                      <div 
                        className={`${styles.subCatAccordionHeader} ${isExpanded ? styles.activeHeader : ''}`}
                        onClick={() => {
                          setActiveSub(prev => (prev === sub ? null : sub));
                        }}
                      >
                        <div className={styles.subCatAccordionTitle}>
                          <span className={styles.subHeaderDot}></span>
                          <span>{t(sub)}</span>
                        </div>
                        <div className={`${styles.subChevronCircle} ${isExpanded ? styles.rotated : ''}`}>
                          <ChevronDown size={18} />
                        </div>
                      </div>

                      <div className={`${styles.accordionBody} ${isExpanded ? styles.expanded : ''}`}>
                        <div className={styles.accordionContent}>
                          <div className={styles.itemGrid}>
                            {CATEGORIES[activeCategory][sub].map(item => (
                              <div key={item} className={styles.categoryLink} onClick={closeCategoryModal}>
                                <Link href={`/ads?category=${item}`}>
                                  <span>{t(item)}</span>
                                  <span className={styles.arrowIcon}>→</span>
                                </Link>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className={styles.noSub}>{t('noSub')}</div>
              )}
            </div>
          </div>
        </div>,
        document.body
      )}

      <div className={`container ${styles.adSection}`}>
        <div className={styles.allAdsCenterWrapper}>
          <Link href="/ads" className={styles.allAdsCenterBtn}>
            {t('allAds')}
          </Link>
        </div>

        {/* ── Featured Business Ads Slider ── */}
        <FeaturedSlider lang={lang} />

        <h2 className={styles.sectionTitle}>{t('freshRecommendations')}</h2>
        <div className={styles.adGrid}>
          {loading ? (
            <div style={{gridColumn: '1/-1', textAlign: 'center', padding: '2rem'}}>Loading...</div>
          ) : listings.length > 0 ? (
            listings.map((ad) => (
              <Link href={`/ad/${ad.id}`} key={ad.id} className={styles.adCard}>
                <div className={styles.adImageWrapper}>
                  {ad.is_verified && (
                    <div className={styles.verifiedBadge}>
                      {lang === 'bn' ? '★ টপ অ্যাড' : '★ Top Ad'}
                    </div>
                  )}
                  {/* Heart / Favorite Button */}
                  <button 
                    className={`${styles.favoriteBtn} ${favorites.includes(ad.id) ? styles.active : ''}`}
                    onClick={(e) => toggleFavorite(e, ad.id)}
                  >
                    <Heart 
                      size={18} 
                      fill={favorites.includes(ad.id) ? "#ef4444" : "none"} 
                      color={favorites.includes(ad.id) ? "#ef4444" : "#64748b"} 
                    />
                  </button>
                  <img 
                    src={ad.images[0] || 'https://via.placeholder.com/300x200?text=No+Image'} 
                    alt={ad.title} 
                    className={styles.adImage}
                  />
                </div>
                <div className={styles.adContent} style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
                  <h3 className={styles.adTitle}>{ad.title}</h3>
                  <p className={styles.adLocation}>
                    {t(ad.location)}
                  </p>
                  {getSellerBadge(ad.profiles, lang) && (
                    <div style={{ display: 'flex', alignItems: 'center', marginTop: '-0.1rem', marginBottom: '0.45rem' }}>
                      {getSellerBadge(ad.profiles, lang)}
                    </div>
                  )}
                  <div className={styles.adPrice}>{formatPrice(ad.price, lang)}</div>
                  <div className={styles.adFooter}>
                    <span className={styles.adTime}>
                      {getRelativeTime(ad.created_at, lang)} • {formatFullDate(ad.created_at, lang)}
                    </span>
                  </div>
                  {ad.is_verified && (
                    <div style={{ marginTop: 'auto', paddingTop: '0.8rem', borderTop: '1px dashed #fef08a', textAlign: 'center' }}>
                      <span style={{ color: '#d97706', fontWeight: 900, fontSize: '0.85rem', letterSpacing: '0.5px', textTransform: 'uppercase', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.3rem' }}>
                        ★ {getPromotionBadgeText(ad.promotion_type, lang)}
                      </span>
                    </div>
                  )}
                </div>
              </Link>
            ))
          ) : (
            <div className={styles.noAds}>{t('noAds')}</div>
          )}
        </div>
      </div>
    </div>
  );
}
